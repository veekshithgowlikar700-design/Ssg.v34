# Price verification sources — 8 Oct 2026

1. Vidya Bernette Sew&Go 1 — current India reference ₹12,399:
https://pricehistory.app/p/bernette-sew-go1-electric-sewing-machine-bernina-fuuMwiw8
Official model information:
https://www.bernette.com/en-IN/models/bernette-sew-go-1

2. Vidya 95T10 Tailor Sewing Machine — ₹9,000:
https://www.tradeindia.com/products/tailor-sewing-machine-9067268.html

3. JACK K7 AI Interlock — ₹1,24,500 expected/market listing:
https://www.justdial.com/india/Jack-Interlock-Sew-Machine

4. JACK F6 — ₹24,000 seller listing:
https://www.aajjo.com/product/jack-f6-sewing-machine-in-chennai-doorstep-enterprises

5. JACK Z7 — official product page confirms model and features, but does not publish an India selling price:
https://www.jack-sewing.com/heavy-duty/jack-Z7/index.html

Important: Machine prices can vary by seller, GST treatment, table/stand, motor, installation, freight and local availability. The app's catalogue price is a shop display price, not a guaranteed online price.
