# GitHub Actions APK build

1. Extract this ZIP on your phone or computer.
2. Upload the **contents** of this folder to the repository (not the ZIP itself). The workflow can also find the Gradle project if the files are inside one extra folder.
3. Commit to `main`, or open Actions and run **Build Android APK** manually.
4. When successful, open the run and download the `SriSaiGanesh-Sewing-debug` artifact.

The workflow searches for `settings.gradle` or `settings.gradle.kts`, validates the app module, builds the debug APK, and uploads it.
